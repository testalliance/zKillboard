--



DROP TABLE IF EXISTS `zz_manual_mail_list`;

/*!40101 SET @saved_cs_client     = @@character_set_client */;

/*!40101 SET character_set_client = utf8 */;

CREATE TABLE `zz_manual_mail_list` (

  `eveKillID` int(16) DEFAULT NULL,

  `processed` int(8) DEFAULT NULL,

  UNIQUE KEY `eveKillID` (`eveKillID`),

  KEY `processed` (`processed`),

  KEY `processed_2` (`processed`,`eveKillID`)

) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPRESSED;

/*!40101 SET character_set_client = @saved_cs_client */;



--

-- Table structure for table `zz_manual_mails`

