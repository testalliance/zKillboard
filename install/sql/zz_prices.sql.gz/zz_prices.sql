--



DROP TABLE IF EXISTS `zz_prices`;

/*!40101 SET @saved_cs_client     = @@character_set_client */;

/*!40101 SET character_set_client = utf8 */;

CREATE TABLE `zz_prices` (

  `typeID` int(16) NOT NULL,

  `price` decimal(32,2) NOT NULL,

  `expires` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (`typeID`),

  KEY `expires` (`expires`)

) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPRESSED;

/*!40101 SET character_set_client = @saved_cs_client */;



--

-- Table structure for table `zz_ranks`

