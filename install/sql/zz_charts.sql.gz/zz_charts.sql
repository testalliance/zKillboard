--



DROP TABLE IF EXISTS `zz_charts`;

/*!40101 SET @saved_cs_client     = @@character_set_client */;

/*!40101 SET character_set_client = utf8 */;

CREATE TABLE `zz_charts` (

  `chartID` int(16) NOT NULL AUTO_INCREMENT,

  `title` varchar(64) NOT NULL,

  `type` varchar(16) NOT NULL,

  `dataset` varchar(4096) NOT NULL,

  PRIMARY KEY (`chartID`),

  KEY `dataset` (`dataset`(767))

) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPRESSED;

/*!40101 SET character_set_client = @saved_cs_client */;



--

-- Table structure for table `zz_comments`

