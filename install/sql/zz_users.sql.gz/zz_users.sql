--



DROP TABLE IF EXISTS `zz_users`;

/*!40101 SET @saved_cs_client     = @@character_set_client */;

/*!40101 SET character_set_client = utf8 */;

CREATE TABLE `zz_users` (

  `id` int(11) NOT NULL AUTO_INCREMENT,

  `username` varchar(128) NOT NULL,

  `moderator` tinyint(1) NOT NULL,

  `admin` tinyint(1) NOT NULL,

  `password` varchar(64) NOT NULL,

  `autoLoginHash` varchar(256) NOT NULL,

  `email` varchar(128) DEFAULT NULL,

  `dateCreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,

  `revoked` smallint(1) NOT NULL DEFAULT '0',

  `change_hash` varchar(40) DEFAULT NULL,

  `change_expiration` timestamp NULL DEFAULT NULL,

  `revoked_reason` varchar(64) NOT NULL,

  PRIMARY KEY (`id`),

  UNIQUE KEY `username` (`username`),

  UNIQUE KEY `email` (`email`),

  KEY `login_index` (`username`,`password`),

  KEY `revoked` (`revoked`)

) ENGINE=InnoDB AUTO_INCREMENT=2276 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPRESSED;

/*!40101 SET character_set_client = @saved_cs_client */;



--

-- Table structure for table `zz_users_config`

