--
-- Struktur-dump for tabellen `zz_campaigns_entities`
--

CREATE TABLE IF NOT EXISTS `zz_campaigns_entities` (
  `id` int(11) NOT NULL,
  `entityType` varchar(64) NOT NULL,
  `entityID` int(11) NOT NULL,
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;