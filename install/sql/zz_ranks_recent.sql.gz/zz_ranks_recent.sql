-- MySQL dump 10.14  Distrib 5.5.30-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: mtlZkb
-- ------------------------------------------------------
-- Server version	5.5.30-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `zz_ranks_recent`
--

DROP TABLE IF EXISTS `zz_ranks_recent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zz_ranks_recent` (
  `type` varchar(16) CHARACTER SET latin1 NOT NULL,
  `typeID` int(16) NOT NULL,
  `shipsDestroyed` int(16) NOT NULL,
  `sdRank` mediumint(16) NOT NULL,
  `shipsLost` int(16) NOT NULL,
  `slRank` mediumint(16) NOT NULL,
  `shipEff` decimal(3,1) NOT NULL,
  `pointsDestroyed` int(16) NOT NULL,
  `pdRank` mediumint(16) NOT NULL,
  `pointsLost` int(16) NOT NULL,
  `plRank` mediumint(16) NOT NULL,
  `pointsEff` decimal(3,1) NOT NULL,
  `iskDestroyed` decimal(32,2) NOT NULL,
  `idRank` mediumint(16) NOT NULL,
  `iskLost` decimal(32,2) NOT NULL,
  `ilRank` mediumint(16) NOT NULL,
  `iskEff` decimal(3,1) NOT NULL,
  `overallRank` mediumint(16) NOT NULL,
  PRIMARY KEY (`type`,`typeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-04-29 12:20:56
