--



DROP TABLE IF EXISTS `zz_irc_log`;

/*!40101 SET @saved_cs_client     = @@character_set_client */;

/*!40101 SET character_set_client = utf8 */;

CREATE TABLE `zz_irc_log` (

  `id` int(11) NOT NULL,

  `nick` varchar(64) NOT NULL,

  `command` varchar(64) NOT NULL,

  `parameters` varchar(256) DEFAULT NULL,

  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,

  KEY `id` (`id`)

) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPRESSED;

/*!40101 SET character_set_client = @saved_cs_client */;



--

-- Table structure for table `zz_irc_mobile`

