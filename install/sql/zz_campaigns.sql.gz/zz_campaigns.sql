--
-- Struktur-dump for tabellen `zz_campaigns`
--

CREATE TABLE IF NOT EXISTS `zz_campaigns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userID` int(11) NOT NULL,
  `campaignTitle` varchar(256) NOT NULL,
  `campaignStart` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `campaignEnd` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `campaignActive` int(11) NOT NULL DEFAULT '1',
  `dateCreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;