--



DROP TABLE IF EXISTS `zz_irc_access`;

/*!40101 SET @saved_cs_client     = @@character_set_client */;

/*!40101 SET character_set_client = utf8 */;

CREATE TABLE `zz_irc_access` (

  `id` int(8) NOT NULL AUTO_INCREMENT,

  `name` varchar(64) NOT NULL,

  `host` varchar(128) NOT NULL,

  `accessLevel` int(8) NOT NULL DEFAULT '0',

  `insertTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (`id`),

  UNIQUE KEY `name_2` (`name`,`host`),

  KEY `insertTime` (`insertTime`),

  KEY `name_3` (`name`)

) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPRESSED;

/*!40101 SET character_set_client = @saved_cs_client */;



--

-- Table structure for table `zz_irc_log`

