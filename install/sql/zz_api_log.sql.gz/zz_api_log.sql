--



DROP TABLE IF EXISTS `zz_api_log`;

/*!40101 SET @saved_cs_client     = @@character_set_client */;

/*!40101 SET character_set_client = utf8 */;

CREATE TABLE `zz_api_log` (

  `logID` int(16) NOT NULL AUTO_INCREMENT,

  `requestTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,

  `errorCode` varchar(128) DEFAULT NULL,

  `scope` varchar(64) DEFAULT NULL,

  `name` varchar(64) DEFAULT NULL,

  `options` varchar(512) DEFAULT NULL,

  PRIMARY KEY (`logID`),

  KEY `requestTime` (`requestTime`,`scope`,`name`),

  KEY `errorCode` (`errorCode`)

) ENGINE=MyISAM AUTO_INCREMENT=53403276 DEFAULT CHARSET=latin1 PAGE_CHECKSUM=1 ROW_FORMAT=COMPRESSED;

/*!40101 SET character_set_client = @saved_cs_client */;



--

-- Table structure for table `zz_blog`

